
    document.getElementById('myCart').addEventListener('click', function(){
      document.querySelector('.cart-modal').style.display='flex';
  });

document.getElementById('right').addEventListener('click', function(){
document.querySelector('.cart-modal').style.display = 'none';
});




