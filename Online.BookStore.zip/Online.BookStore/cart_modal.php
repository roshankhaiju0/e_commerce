<div class="cart-modal">
                <div class="cart-modal-content">
                    <div class="cart">

                        <div class="cart-top">
                            <p><i class="right-carret" id="right">&#62;</i>Cart</p>
                        </div><!-- cart-top section close -->

                        <div class="cart-mid">
                            <div class="cart-mid-des">
                                <div class="cart-mid-des-bookBx">
                                    <img src="../images/recommended/recommended-img-3.png" alt="">
                                </div><!-- cart-mid-des-bookBx section close -->
                                <div class="cart-mid-des-bookDes">
                                    <p>I'm a Product <br>
                                        <strong>QTY: 3</strong><br>
                                        <strong>Rs. 25.00</strong>
                                    </p>
                                </div><!-- cart-mid-des-bookDes section close -->
                                <div class="cart-mid-des-cross">
                                    <i>&times;</i>
                                </div><!-- cart-mid-des-cross section close -->
                            </div><!-- cart-mid-des section -->

                            <div class="cart-mid-des">
                                <div class="cart-mid-des-bookBx">
                                    <img src="../images/recommended/recommended-img-4.png" alt="">
                                </div><!-- cart-mid-des-bookBx section close -->
                                <div class="cart-mid-des-bookDes">
                                    <p>I'm a Product <br>
                                        <strong>QTY: 3</strong><br>
                                        <strong>Rs. 25.00</strong>
                                    </p>
                                </div><!-- cart-mid-des-bookDes section close -->
                                <div class="cart-mid-des-cross">
                                    <i>&times;</i>
                                </div><!-- cart-mid-des-cross section close -->
                            </div><!-- cart-mid-des section -->

                            <div class="cart-mid-des">
                                <div class="cart-mid-des-bookBx">
                                    <img src="../images/recommended/recommended-img-6.png" alt="">
                                </div><!-- cart-mid-des-bookBx section close -->
                                <div class="cart-mid-des-bookDes">
                                    <p>I'm a Product <br>
                                        <strong>QTY: 2</strong><br>
                                        <strong>Rs. 25.00</strong>
                                    </p>
                                </div><!-- cart-mid-des-bookDes section close -->
                                <div class="cart-mid-des-cross">
                                    <i>&times;</i>
                                </div><!-- cart-mid-des-cross section close -->
                            </div><!-- cart-mid-des section -->
                        </div><!-- cart-mid section close -->

                        <div class="cart-bottom">
                            <p>Subtotal <br> Rs. 200.00</p>
                            <hr>
                            <button><a href="../includes/customer.php?source=view_cart"> View Cart</a></button>
                        </div><!-- cart-bottom section close -->

                    </div><!-- cart section close -->
                </div><!-- cart-modal-content section close -->
            </div><!-- cart-modal section close -->