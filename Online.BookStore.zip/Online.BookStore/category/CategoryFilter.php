<?php

    if (isset($_GET['bookCat'])) {
        $bookCat = $_GET['bookCat'];

    }

    if (isset($_POST['submit'])) {
        $min = $_POST['min'];
        $max = $_POST['max'];

        if ($bookCat == 'all') {
            $query  = "SELECT * FROM books WHERE bookPrice BETWEEN '$min' AND '$max' ORDER BY bookPrice ";
            $result = mysqli_query($connection, $query);
            if (!$result) {
                echo ' Failed';
            }
        } else {
            $query  = "SELECT * FROM books WHERE (bookCategory = '$bookCat' AND bookPrice BETWEEN '$min' AND '$max') OR (bookCategory = '$bookCat' AND bookPrice BETWEEN '$min' AND '$max') ";
            $result = mysqli_query($connection, $query);
            if (!$result) {
                echo 'Query ';
            }
        }

    }

    if (isset($_POST['search'])) {
        $bookTag = $_POST['searchBook'];

        if ($bookCat == 'all') {
            $query  = "SELECT * FROM books WHERE (bookName = '$bookTag') OR (bookAuthor = '$bookTag') ";
            $result = mysqli_query($connection, $query);
            if (!$result) {
                echo ' Failed';
            }
        } else {
            $query  = "SELECT * FROM books WHERE (bookCategory = '$bookCat' AND bookName = '$bookTag') OR (bookCategory = '$bookCat' AND bookAuthor = '$bookTag') ";
            $result = mysqli_query($connection, $query);
            if (!$result) {
                echo 'Query ';
            }
        }

    }

?>




<style>
.searchBook {
    height: 25px;
    width: 170px;
    font-size: 1rem;
    border: none;
    border-bottom: 2px solid #ccc;
    color: rgba(16, 18, 74, 0.5);
    ;
}

form p {
    font-size: 1.2rem;
    color: var(--primary-2);
}

input {
    height: 25px;
    width: 60px;
    font-size: 1rem;
    margin-right: 10px;
    border-color: rgba(16, 18, 74, 0.5);
    ;
    color: rgba(16, 18, 74, 0.5);
}

.search {
    width: 74px;
    height: 28px;

    background: #ffffff;
    border: 1px solid var(--primary);
    box-sizing: border-box;
    border-radius: 5px;

    font-size: 14px;
    line-height: 14px;

    color: var(--primary);
}

.search:hover {
    background-color: #007cd6;
    color: #fff;
    border: none;
    transition: 0.3s;
    cursor: pointer;
}

</style>
