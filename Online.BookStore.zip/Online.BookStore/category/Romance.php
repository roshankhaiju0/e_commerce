<?php
    include "../includes/header.php";
    require_once "../config/db.php";
    include "../category/CategoryFilter.php";

    $query  = "SELECT * FROM books WHERE bookCategory = 'Romance'";
    $result = mysqli_query($connection, $query);

?>

<main>
    <div class="bookstore-cnt">

        <div class="heading">
            <div class="hd-top">
                <p>Online. Book Store</p>
            </div><!-- hd-top section close -->
            <div class="hd-bottom">
                <p>ROMANCE</p>
            </div><!-- hd-bottom section close -->
        </div><!-- heading section close -->

        <div class="bookstore-bk">
          
          <div class="search-filter">
          <div class="heading">
              Search By
          </div><!-- filter by heading seciton close -->
          <br>
          <hr>
          <br>
          <form action="" method="post" class="bookSearch">
              <input type="text" class="searchBook" name="searchBook" placeholder="book name, author name...">
              <button type="submit" name="search" class="search"><a href="../includes/books.php?source=searchBook"> Search</a></button>
          </form>
          <br>
          <hr>
          <br>
          <ul>
              <li style="margin-bottom: 10px;"><a>Categories</li>
              <li><a href="../includes/books.php?source=">All</a></li>
              <li><a href="../includes/books.php?source=fiction">Fiction</a></li>
              <li><a href="../includes/books.php?source=design">Design & Art</a></li>
              <li><a href="../includes/books.php?source=romance">Romance</a></li>
              <li><a href="../includes/books.php?source=travel">Travel Guide</a></li>
              <li><a href="../includes/books.php?source=thriller">Thriller</a></li>
              <li><a href="../includes/books.php?source=adventure">Adventure</a></li>
          </ul>
          <br>
          <hr>
          <br>
          <li><a href="#">Price</a></li>
          <br>
          <form action="" method="POST">
              <p> Min: <input type="number" name="min"> Max: <input type="number" name="max"></p><br>
              <button type="submit" name="submit" class="search"><a href="../includes/books.php?source=bookPrice"> Search</a></button>
          </form>
      </div><!-- search filter section close -->

            <div class="cnt-books">

                <?php
                    while ($row = mysqli_fetch_array($result)) {
                    ?>

                <div class="cnt-books-card">
                    <div class="cnt-books-img-bx">
                        <a href="bookDescription.php"><?php echo '<img src="data:image;base64,' . base64_encode($row['bookImage']) . '" alt="image">'; ?>
                            <div><a href="../includes/books.php?source=description&description=<?php echo $row['id'] ?>">View Detail</a>
                            </div>
                        </a>
                    </div><!-- cnt-books-img-bx section close -->
                    <p><?php echo $row['bookName'] ?><br>Rs.<?php echo $row['bookPrice'] ?></p>
                </div><!-- cnt-books-card section close -->



                <?php
                    }
                ?>

            </div><!-- cnt-books section close -->

        </div><!-- bookstore-bk section close -->

    </div><!-- bookstore-cnt section close -->

</main><!-- main section close -->

<?php include "../includes/footer.php" ?>


</body>

</html>
