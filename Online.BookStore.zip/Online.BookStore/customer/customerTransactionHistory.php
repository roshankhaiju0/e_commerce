<?php
    include "../includes/header.php";
    require_once "../config/db.php";

    $transaction_customer_id     = $_SESSION['userId'];
    $customer_transactions       = "SELECT * FROM customer_transactions  WHERE user_id = '$transaction_customer_id' ORDER BY order_id DESC";
    $customer_transaction_result = mysqli_query($connection, $customer_transactions);
    if (!$customer_transaction_result) {
        die("QUERY FAILED" . mysqli_error($connection));
    }
    
?>

<div class="customerTransaction">

    <div class="heading">
        <p><a>Transaction History</a></p>
    </div><!-- heading section close -->

    <div class="bookListHead">

        <div class="bookOrderedpdthead">
            <p>Description</p>
        </div><!-- pdthead section close -->

        <div class="bookOrderedDatehead">
            <p>Purchased Date</p>
        </div><!-- bookOrderDatehead section close -->

        <div class="bookOrderedCustomerhead">
            <p>Vendor</p>
        </div><!-- bookOrderCustomerhead section close -->

        <div class="bookOrderedPricehead">
            <p>Price</p>
        </div><!-- bookPricehead section close -->

        <div class="bookOrderedQtyhead">
            <p>Quantity</p>
        </div><!-- bookQtyhead section close -->

        <div class="bookOrderedTotalhead">
            <p>Total</p>
        </div><!-- bookOrderTotalhead section close -->

    </div><!-- bookListHead section close -->

    <hr>

    <div class="bookList">

        <?php
            while ($row6 = mysqli_fetch_array($customer_transaction_result)) {
                $order_id = $row6['order_id'];
                $order_date = $row6['order_date'];                    

                    $query2  = "SELECT * FROM admin_cart WHERE order_id = '$order_id'";
                    $result2 = mysqli_query($connection, $query2);
                    if (!$result2) {
                        die("QUERY FAILED" . mysqli_error($connection));
                    }
                    while ($row = mysqli_fetch_array($result2)) {
                        $book_id     = $row['book_id'];
                        $total_price = $row['total_price'];
                        $qty         = $row['quantity'];
                        $user_id = $row['user_id'];
                    }

                    $query3  = "SELECT * FROM books WHERE id = '$book_id'";
                    $result3 = mysqli_query($connection, $query3);
                    if (!$result3) {
                        die("QUERY FAILED" . mysqli_error($connection));
                    }
                    while ($row = mysqli_fetch_array($result3)) {
                        $book_name      = $row['bookName'];
                        $book_author    = $row['bookAuthor'];
                        $book_price     = $row['bookPrice'];
                        $book_category  = $row['bookCategory'];
                        $book_publisher = $row['bookPublisher'];
                        $book_isbn      = $row['bookISBN'];
                        $book_image     = $row['bookImage'];
                        $vendor_id      = $row['bookVendor'];
                    }

                    $query4  = "SELECT * FROM customerusers WHERE id = '$user_id'";
                    $result4 = mysqli_query($connection, $query4);
                    if (!$result4) {
                        die("QUERY FAILED" . mysqli_error($connection));
                    }
                    while ($row = mysqli_fetch_array($result4)) {
                        $customer_name = $row['username'];
                    }

                    $query5  = "SELECT * FROM vendorusers WHERE id = '$vendor_id'";
                    $result5 = mysqli_query($connection, $query5);
                    if (!$result5) {
                        die("QUERY FAILED" . mysqli_error($connection));
                    }
                    while ($row = mysqli_fetch_array($result5)) {
                        $vendor_name = $row['vendorName'];
                    }

            ?>

        <div class="pdt">

            <div class="bookBx">
                <?php echo '<img src="data:image;base64,' . base64_encode($book_image) . '" alt="image">'; ?>
            </div><!-- bbokBx section close -->
            <div class="bookDesc">
                <div class="book-head">
                    <p><?php echo $book_name ?></p>
                </div><!-- book-head section close -->

                <div class="book-detail">

                    <div class="book-detail-1">
                        <li>Author:</li>
                        <li>Publisher:</li>
                        <li>Category:</li>
                        <li>ISBN:</li>
                    </div><!-- book-detail-1 section close -->

                    <div class="book-detail-2">
                        <li><?php echo $book_author ?></li>
                        <li><?php echo $book_publisher ?></li>
                        <li><?php echo $book_category ?></li>
                        <li><?php echo $book_isbn ?></li>
                    </div><!-- book-detail-2 section close -->

                </div><!-- book-detail section close -->
            </div><!-- bookDesc section close -->

        </div><!-- pdt section close -->

        <div class="bookOrderedDate">
            <div class="bookOrderedDateCnt">
                <p><?php echo $order_date ?></p>
            </div><!-- bookOrderDateCnt section close -->
        </div><!-- bookOrderDate section close -->

        <div class="bookOrderedCustomer">
            <div class="bookOrderedCustomerCnt">
                <p><?php echo $vendor_name ?></p>
            </div><!-- bookOrderCustomerCnt section close -->
        </div><!-- bookOrderCustomer section close -->

        <div class="bookOrderedPrice">

            <div class="bookOrderedPriceCnt">
                <p>Rs.                                             <?php echo $book_price ?></p>
            </div><!-- bookOrderPriceCnt section close -->

        </div><!-- bookOrderPrice section close -->

        <div class="bookOrderedQty">

            <div class="bookOrderedQtyCnt">
                <p><?php echo $qty ?></p>
            </div><!-- bookOrderQtyCnt section close -->

        </div><!-- bookOrderQty section close -->

        <div class="bookOrderedTotal">
            <div class="bookOrderedTotalCnt">
                <p>Rs.                                             <?php echo $total_price ?></p>
            </div><!-- bookOrderTotalCnt section close -->
        </div><!-- bookOrderTotal section close -->

        <?php } ?>

    </div><!-- bookList section close -->

    <hr>

</div><!-- vendorTransaction section close -->

<?php
    include "../includes/footer.php";
?>

<script src="../js/main.js"></script>


</body>

</html>
