<?php
    include "../includes/header.php";
    require_once "../config/db.php";
    $user_id = $_SESSION['userId'];

    $query  = "SELECT * FROM cart WHERE user_id = '$user_id' ";
    $result = mysqli_query($connection, $query);

    $total_price = 0;

?>

<div class="bg-modal">
    <div class="modal-content">
        <div class="close">+</div>
        <div class="msg">
            Order will <br> Deliver Soon
        </div>
    </div><!-- deliver-soon section close -->
</div><!-- modal-content section close -->
</div><!-- bg-modal section close -->

<div class="myCart_orderSummary">



    <div class="myCart">

        <div class="heading">
            <p>My Cart</p>
            <hr>
        </div><!-- heading section close -->


        <!-- <div class="myCartpdt-section"> -->
        <form action="" method="post" class="myCartpdt-section">

            <?php

                if ($cart_count == 0) {
                    echo '<p style="text-align:center;font-size:20px;color:rgba(0,0,0,0.5);margin-top:50px;">Cart is empty</p>';
                } else {

                    while ($row = mysqli_fetch_array($result)) {
                        $book_id = $row['book_id'];

                        $query2  = "SELECT * FROM books WHERE id = '$book_id'";
                        $result2 = mysqli_query($connection, $query2);
                        while ($row2 = mysqli_fetch_array($result2)) {
                        ?>

            <div class="myCartpdt">
                <div class="myCartpdt-imgbx">
                    <?php echo '<img src="data:image;base64,' . base64_encode($row2['bookImage']) . '" alt="image">'; ?>
                </div><!-- myCartpdt-imgbx -->
                <div class="myCartpdt-name">
                    <p><?php echo $row2['bookName'] ?> <br><span class="price">Rs.<?php echo $row['price'] ?></span></p>
                </div><!-- myCartpdt-name -->
                <div class="myCartpdt-qty">
                    <input type="tel" name="book_qty" maxlength="4" size="4" value="<?php echo $row['quantity'] ?>">
                </div><!-- myCartpdt-qty -->
                <div class="myCartpdt-price">
                    <p>Rs. <?php echo $row['total_price'] ?></p>
                </div><!-- myCartpdt-price -->
                <div class="myCartpdt-cross">

                    <i class="close" name="delete"><a
                            href="../includes/customer.php?source=view_cart&delete=<?php echo $row['order_id'] ?>">&times;</a></i>
                </div><!-- myCartpdt-name -->
            </div><!-- myCartpdt section close -->
            <hr>
            <?php $total_price = $total_price + $row['total_price'] ?>
            <?php }}}
    if (isset($_GET['delete'])) {
        $delete_cart  = $_GET['delete'];
        $query        = "DELETE FROM cart WHERE order_id = '$delete_cart'";
        $delete_query = mysqli_query($connection, $query);
    }

?>

        </form>
        <!-- </div> -->
        <!-- myCartpdt-section close-->

    </div><!-- myCart section close -->
    <form action="" method="post">

        <div class="orderSummary">

            <div class="heading">
                <p>Order Summary</p>
                <hr>
            </div><!-- heading section close -->

            <div class="orderSummary-top">
                <div class="orderSummary-lf">
                    <p>Subtotal</p><br>
                    <p>Shipping</p>
                </div><!-- orderSummary-lf section close -->
                <div class="orderSummary-rt">
                    <p>Rs. <?php echo $total_price ?></p><br>
                    <p>FREE</p>
                </div><!-- orderSummary-rt section close -->
            </div><!-- orderSummary-top section close -->

            <input type="text" name="location" id="location" placeholder="enter deliver location..." width="50" style=" width: 90%;
    box-sizing: border-box;
    border: none;
    border-bottom: 2px solid rgba(0, 0, 0, 0.5);;
    margin: 30px 0 ;
    font-size: 18px;
    outline: none;">

            <hr>

            <div class="orderSummary-bottom">
                <div class="orderSummary-lf">
                    <p style="font-size: 24px;
                line-height: 26px;
                color: #10124A;">Total</p>
                </div><!-- orderSummary-lf section close -->
                <div class="orderSummary-rt">
                    <p style="font-size: 24px;
                line-height: 26px;text-align: right;
                color: #10124A;">Rs. <?php echo $total_price ?></p>
                </div><!-- orderSummary-rt section close -->
            </div><!-- orderSummary-bottom section close -->

            <button type="submit" name="submit" id=""><i class="fas fa-lock"></i>
                Checkout</button>

        </div><!-- orderSummary section close -->

    </form>

</div><!-- myCart_orderSummary section close -->

<?php
    include "../includes/footer.php";

    if (isset($_POST['submit'])) {

        // $column_cnt = mysqli_query($connection, "SELECT COUNT(order_id) FROM cart");

        // $field_cnt = mysqli_num_fields($column_cnt);
        // echo $field_cnt;

        $deliver_location = $_POST['location'];
        if (empty($deliver_location)) {
            echo '<script>alert("deliver location cannot be empty")</script>';
            die(header("Location: ../includes/customer.php?source=view_cart"));
        } else {
            $deliver_location = ucfirst($deliver_location);

            $query3  = "SELECT * FROM cart ";
            $result3 = mysqli_query($connection, $query3);
            while ($row = mysqli_fetch_array($result3)) {
                $order_id    = $row['order_id'];
                $customer_id = $row['user_id'];
                $vendor_id   = $row['vendor_id'];
                $purchased_date = $row['order_date'];

                $query4  = "SELECT * FROM order_request WHERE order_id = '$order_id'";
                $result4 = mysqli_query($connection, $query4);
                while ($row4 = mysqli_fetch_array($result4)) {
                    $or_oid = $row4['order_id'];

                }
                if ($or_oid !== $order_id) {
                    $admin_cart_query        = "INSERT INTO `admin_cart` SELECT * FROM `cart`";
                    $admin_cart_query_result = mysqli_query($connection, $admin_cart_query);

                    $query2  = "INSERT INTO `order_request`(`order_id`, `purchased_date`, `deliver_location`, `customer_id`, `vendor_id`) VALUES ('$order_id', '$purchased_date', '$deliver_location','$customer_id','$vendor_id')";
                    $result2 = mysqli_query($connection, $query2);

                    $query        = "DELETE FROM cart WHERE order_id = {$order_id}";
                    $delete_query = mysqli_query($connection, $query);
                    echo "<script>window.open('../customer/myCart-orderSummary.php','_self');</script>";
                } else {
                    echo '<script>alert("item already requested")</script>';
                }
            }
        }

        // $query4  = "SELECT * FROM order_request";
        // $result4 = mysqli_query($connection, $query4);
        // while ($row = mysqli_fetch_array($result4)) {
        //     $or_oid = $row['order_id'];
        // }

        // $query3  = "SELECT * FROM cart ";
        // $result3 = mysqli_query($connection, $query3);
        // while ($row = mysqli_fetch_array($result3)) {
        //     $order_id = $row['order_id'];

        //     $query4  = "SELECT * FROM order_request WHERE order_id = '$order_id'";
        //     $result4 = mysqli_query($connection, $query4);
        //     while ($row4 = mysqli_fetch_array($result4)) {
        //         $or_oid = $row4['order_id'];
        //     }
        //     if ($or_oid !== $order_id) {
        //         $query2  = "INSERT INTO `order_request`(`order_id`, `deliver_location`) VALUES ('$order_id','$deliver_location')";
        //         $result2 = mysqli_query($connection, $query2);
        //     }
        // }

        // if ($or_oid !== $order_id) {
        //     $query2  = "INSERT INTO `order_request`(`order_id`, `deliver_location`) VALUES ('$order_id','$deliver_location')";
        //     $result2 = mysqli_query($connection, $query2);
        // } else {
        //     echo '<script>alert("item already requested")</script>';
        // }

    }

?>

<script src="../js/main.js"></script>
<script>
document.getElementById('myBtn').addEventListener('click', function() {
    document.querySelector('.bg-modal').style.display = 'flex';
});

document.querySelector('.close').addEventListener('click', function() {
    document.querySelector('.bg-modal').style.display = 'none';
});
</script>


</body>

</html>
