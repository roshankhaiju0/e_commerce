<?php
    include "../includes/header.php";
    require_once "../config/db.php";

    if (isset($_POST['submit'])) {

        $username        = $_POST['username'];
        $password        = $_POST['password'];
        $passwordConfirm = $_POST['passwordConfirm'];
        $userType        = 'customer';

        if ($connection) {
            if (!$username || !$password || !$passwordConfirm) {
                echo '<script type="text/javascript">alert("field cannot be empty")</script>';
            } elseif ($password != $passwordConfirm) {
                echo '<script type="text/javascript">alert("password did not match")</script>';
            } else {

                $query  = "SELECT * FROM customerusers";
                $result = mysqli_query($connection, $query);

                $query2 = "SELECT * FROM vendorusers";
                $result2 = mysqli_query($connection, $query2);

                while ($row = mysqli_fetch_array($result)) {
                    $db_username = $row['username'];
                    $db_password = $row['password'];
                }

                while ($row = mysqli_fetch_array($result2)) {
                    $db_username2 = $row['username'];
                    $db_password2 = $row['password'];
                }

                if ($username == $db_username || $password == $db_password || $username == $db_username2 || $password == $db_password2) {
                    echo '<script>alert("Username or Password already taken")</script>';
                } else {
                    $query = "INSERT INTO customerusers";
                    $query .= "(username, password, userType)";
                    $query .= "VALUES ('$username', '$password', '$userType')";

                    $result = mysqli_query($connection, $query);

                    if (!$result) {
                        die('Query failed' . mysqli_error($connection));
                    } else {
                        echo '<script type="text/javascript">alert("account created  successfully")</script>';
                    }
                }

            }
        } else {
            die("connection failed");
        }

    }

?>

<main>

    <div class="loginSection">

        <div class="head">
            <div class="head-top">
                <p>Sign Up as Customer</p>
            </div><!-- head-top section close -->
            <div class="head-bottom">
                <p>Already have an account? <a href="../includes/LogIn_SignUp.php?source=customer_login"> Log In</a></p>
            </div><!-- head-bottom section close -->
        </div><!-- head section close -->

        <div class="loginForm">
            <div class="loginFormCustomer">

                <form action="" method="post">
                    <div class="namePass">
                        <input type="text" name="username" placeholder="Username or Email">
                        <hr>
                        <input type="password" name="password" placeholder="Password">
                        <hr>
                        <input type="password" name="passwordConfirm" placeholder="Type your password again">
                        <hr>

                    </div><!-- namePass section close -->

                    <button type="submit" name="submit">Sign Up</button>
                </form>
            </div><!-- loginForm-lf section close -->

        </div><!-- loginFOrm section close -->

        <div class="foot">
            <p>* By looging in, you agree to our Terms of Use and to <br>
                receive Online. Book Store emails & updates and acknowledge that you <br>
                read our Privacy Policy.</p>
        </div><!-- foot section close -->

    </div><!-- login section close -->

</main>

<?php
    include "../includes/footer.php";
?>

</body>

</html>
