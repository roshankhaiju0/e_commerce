<?php
    include "../includes/header.php";
    require_once "../config/db.php";
    
?>

<?php
    if (isset($_POST['login'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];

        $username = mysqli_real_escape_string($connection, $username);
        $password = mysqli_real_escape_string($connection, $password);

    $query = "SELECT * FROM customerusers WHERE username = '{$username}' ";
    $select_user_query = mysqli_query($connection, $query);
    if(!$select_user_query){
        die("QUERY FAILED" . mysqli_error($connection));
    }

    while($row = mysqli_fetch_array($select_user_query)){
       $_SESSION['userId'] = $db_id = $row['id'];
       $_SESSION['username'] = $db_username = $row['username'];
       $_SESSION['password'] = $db_password = $row['password'];
       $_SESSION['userType'] = $db_userType = $row['userType'];
    }

    if($username !== $db_username && $password !== $db_password){
        header("Location: ../includes/LogIn_SignUp.php?source=customer_login");
    }elseif($username == $db_username && $password == $db_password){
        header("Location: ../pages/index.php");
    }else{
        header("Location: ../includes/LogIn_SignUp.php?source=customer_login");
    }

    }
?>

<main>

    <div class="loginSection">

        <div class="head">
            <div class="head-top">
                <p>Log In as Customer</p>
            </div><!-- head-top section close -->
            <div class="head-bottom">
                <p>New to Online. Book Store? <a href="../includes/LogIn_SignUp.php?source=customer_signup"> Sign Up</a>
                </p>
            </div><!-- head-bottom section close -->
        </div><!-- head section close -->

        <div class="loginForm">

            <form action="" class="loginFormCustomer" method="post">
                <div class="namePass">
                    <input type="text" name="username" placeholder="Username or Email">
                    <hr>
                    <input type="password" name="password" placeholder="Password">
                    <hr>
                </div><!-- namePass section close -->

                <div class="forgetPass">
                    <p><input type="checkbox"> Remember Me</p>
                    <a href="#">Forget Password?</a>
                </div><!-- forgetPass section close -->

                <button type="submit" name="login">Log In</button>
            </form>


        </div><!-- loginFOrm section close -->

        <div class="foot">
            <p>* By looging in, you agree to our Terms of Use and to <br>
                receive Online. Book Store emails & updates and acknowledge that you <br>
                read our Privacy Policy.</p>
        </div><!-- foot section close -->

    </div><!-- login section close -->

</main>

<?php
    include "../includes/footer.php";
?>

</body>

</html>
