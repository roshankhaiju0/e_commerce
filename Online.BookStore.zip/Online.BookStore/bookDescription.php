<?php
    include "../includes/header.php";
    require_once "../config/db.php";

    if (isset($_GET['description'])) {
        $description = $_GET['description'];

        $query             = "SELECT * FROM books WHERE id = $description ";
        $description_query = mysqli_query($connection, $query);

    }

    if (isset($_POST['addCart'])) {
        if (isset($_SESSION['username'])) {
            echo '<script type="text/javascript">alert("book is added to cart ")</script>';
        } else {
            echo '<script type="text/javascript">alert("login as customer for add to cart")</script>';
            echo '<a href="../includes/books.php?source=description"></a>';
        }
    }

?>



<main>


    <div class="bg-modal">
        <div class="modal-content">
            <div class="modal-head">
                <p>Share Your Thought</p>
                <div class="close">+</div><!-- close section close -->
            </div><!-- modal-head section close -->
            <hr>
            <form action="#" method="POST">
                <label for="Rating">Rating</label>
                <select name="" id="input" style="margin-left: 45px;">
                    <option>
                        <p>select rating....</p>
                    </option>
                    <option value="1">
                        &#11088;
                    </option>
                    <option value="2">
                        &#11088;&#11088;
                    </option>
                    <option value="3">
                        &#11088;&#11088; &#11088;
                    </option>
                    <option value="4">
                        &#11088;&#11088; &#11088; &#11088;
                    </option>
                    <option value="5">
                        &#11088; &#11088; &#11088;&#11088; &#11088;
                    </option>
                </select><br>
                <p class="label">Content</p>
                <textarea placeholder="write your review here ...."></textarea>
                <br>
                <button type="submit">Submit</button>
            </form>
        </div><!-- modal-content section close -->
    </div><!-- bg-modal section close -->

    <div class="bookDescription">

        <?php

            while ($row = mysqli_fetch_array($description_query)) {

            ?>

        <div class="bookDescription-img">
            <?php echo '<img src="data:image;base64,' . base64_encode($row['bookImage']) . '" alt="image">'; ?>
        </div><!-- bookDescription-img section close -->

        <div class="bookDescription-price">
            <p><span class="fnt30"><?php echo $row['bookName'] ?></span><br><br><span class="fnt24">Rs.
                    <?php echo $row['bookPrice'] ?></span><br><br><span class="fnt20">Quantity</span></p>
            <br>
            <form action="" method="post">

                <input type="number" name="qty" min="1" max="10" width="48" height="48">
                <br>
                <button type="submit" name="addCart" class="add-cart">Add to Cart</button>
            </form>

        </div><!-- bookDescription-price section close -->

        <div class="bookDescription-info">
            <div class="book-head">
                <p>PRODUCT INFO</p>
            </div><!-- book-head section close -->

            <div class="book-detail">

                <div class="book-detail-1">
                    <li>Author:</li>
                    <li>Publisher:</li>
                    <li>Category:</li>
                    <li>ISBN:</li>
                </div><!-- book-detail-1 section close -->

                <div class="book-detail-2">
                    <li><?php echo $row['bookAuthor'] ?></li>
                    <li><?php echo $row['bookPublisher'] ?></li>
                    <li><?php echo $row['bookCategory'] ?></li>
                    <li><?php echo $row['bookISBN'] ?></li>
                </div><!-- book-detail-2 section close -->

            </div><!-- book-detail section close -->
        </div><!-- bookDescription-info section close -->

        <div class="bookDescription-des">
            <p><?php echo $row['bookDescription'] ?></p>
        </div><!-- bookDescription-des section close -->

        <div class="bookDescription-rating">
            <p class="rating-hd">Average Rating</p><br>
            <i class="far fa-star"></i>
            <i class="far fa-star"></i>
            <i class="far fa-star"></i>
            <i class="far fa-star"></i>
            <i class="far fa-star"></i>
            <br><br>
            <button id="myBtn"><i class="fas fa-comment-alt"></i> Write a review</button>
        </div><!-- book-rating section close -->

        <?php
            }
        ?>

    </div><!-- bookDescription section close -->

    <div class="review-rating">

        <div class="review-rating-hd">
            <p>Ratings & Reviews</p>
        </div><!-- review-rating-hd section close -->

        <div class="review-rating-user">
            <div class="user">
                <img src="../images/user-icon/LogoMakr_2b1cLk.png" alt="userImage">
                <p>User Name</p>
            </div><!-- user section close -->
            <div class="user-rating">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="far fa-star"></i>
            </div><!-- user rating section close -->
            <div class="user-review">
                <p>Iaculis urna id volutpat lacus laoreet non curabitur gravida arcu. Velit scelerisque in
                    dictum non. Nec
                    ullamcorper sit amet risus nullam eget felis eget nunc. Feugiat vivamus at augue eget arcu
                    dictum varius.
                    Elementum tempus egestas sed sed risus pretium quam vulputate dignissim. Et malesuada fames
                    ac turpis.
                    Tempor commodo ullamcorper a lacus. Nunc consequat interdum varius sit amet mattis. Lectus
                    mauris </p>
            </div><!-- user-review section close -->

        </div><!-- review-rating-user-->

        <div class="review-rating-user">
            <div class="user">
                <img src="../images/user-icon/LogoMakr_4h58Ie.png" alt="userImage">
                <p>User Name</p>
            </div><!-- user section close -->
            <div class="user-rating">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="far fa-star"></i>
            </div><!-- user rating section close -->
            <div class="user-review">
                <p>Iaculis urna id volutpat lacus laoreet non curabitur gravida arcu. Velit scelerisque in
                    dictum non. Nec
                    ullamcorper sit amet risus nullam eget felis eget nunc. Feugiat vivamus at augue eget arcu
                    dictum varius.
                    Elementum tempus egestas sed sed risus pretium quam vulputate dignissim. Et malesuada fames
                    ac turpis.
                    Tempor commodo ullamcorper a lacus. Nunc consequat interdum varius sit amet mattis. Lectus
                    mauris </p>
            </div><!-- user-review section close -->

        </div><!-- review-rating-user-->

    </div><!-- review-rating section close -->

</main><!-- main section close -->

<?php include "../includes/footer.php" ?>


<style>
.bg-modal {
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.7);
    top: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    display: none;
    position: fixed;
}

.modal-content {
    width: 928px;
    height: 557px;
    background-color: #fff;
    border-radius: 10px;
    box-shadow: -5px 5px 4px rgba(0, 0, 0, 0.5);
    text-align: center;
    padding: 20px;
    position: relative;
}

.modal-head p {
    font-size: 36px;
    line-height: 44px;
    color: #073C5B;
    margin-bottom: 15px;
}

label,
.label {
    font-size: 30px;
    line-height: 37px;
    color: #073C5B;
}

.label {
    position: absolute;
    left: 180px;
    top: 230px
}

.modal-content form input,
#input,
textarea {
    width: 50%;
    height: 47px;
    border: 1px solid rgba(0, 0, 0, 0.5);
    box-sizing: border-box;
    border-radius: 10px;
    margin: 30px 0 0 30px;
    font-size: 20px;
    outline: none;
}

textarea {
    resize: none;
    width: 450px;
    height: 250px;
    margin-left: 130px;
    padding: 5px;
}

.close {
    position: absolute;
    top: 10px;
    right: 20px;
    font-size: 42px;
    transform: rotate(45deg);
    cursor: pointer;
}

.modal-content form {
    margin-top: 52px;
}

.modal-content button {
    position: absolute;
    width: 192px;
    height: 41px;
    left: 330px;
    bottom: 56px;
    background: #073C5B;
    border: none;
    outline: none;

    font-size: 22px;
    line-height: 24px;
    text-align: center;
    color: #FFFFFF;
}

.modal-content button:hover {
    background-color: rgb(0, 88, 151);
    transition: .3s;
    cursor: pointer;
}

</style>

<script>
document.getElementById('myBtn').addEventListener('click', function() {
    document.querySelector('.bg-modal').style.display = 'flex';
});
document.querySelector('.close').addEventListener('click', function() {
    document.querySelector('.bg-modal').style.display = 'none';
});
</script>

</body>

</html>
