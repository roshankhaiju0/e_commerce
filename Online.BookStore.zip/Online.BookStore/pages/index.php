<?php
    include "../includes/header.php";
    require_once "../config/db.php";

    $query  = "SELECT * FROM books LIMIT 5";
    $result = mysqli_query($connection, $query);
    $result2 = mysqli_query($connection, $query);

?>

<main>
    <div class="banner">
        <img src="../images/banner-img.png" alt="banenr-img">
    </div><!-- banner section close -->

    <div class="content">

        <div class="content-1">
            <div class="heading">
                <div class="hd-top">
                    <p>Online. Book Store</p>
                </div><!-- hd-top section close -->
                <div class="hd-bottom">
                    <p>BESTSELLERS</p>
                </div><!-- hd-bottom section close -->
            </div><!-- heading section close -->
            
            <div class="bookSlider">
                <?php
                    while ($row = mysqli_fetch_array($result)) {
                ?>
                <div class="cardBox">
                    <div class="bookBox">
                        <a href="../includes/books.php?source=description&description=<?php echo $row['id'] ?>"><?php echo '<img src="data:image;base64,' . base64_encode($row['bookImage']) . '" alt="image">'; ?>
                            <div>View Detail</div>
                        </a>
                    </div><!-- bookBox section close -->
                    <p><?php echo $row['bookName'] ?><br>Rs.<?php echo $row['bookPrice'] ?></p>
                </div><!-- cardBox section close -->

                <?php } ?>

            </div><!-- bookSlider section closer -->

        </div><!-- content-1 section close -->
        

        <div class="content-2">
            <div class="line"></div>
            <div class="heading">
                <div class="hd-top">
                    <p>Online. Book Store</p>
                </div><!-- hd-top section close -->
                <div class="hd-bottom">
                    <p>RECOMMENDED BOOKS</p>
                </div><!-- hd-bottom section close -->
            </div><!-- heading section close -->
            <div class="line"></div>

            <div class="bookSlider">
                <?php
                    while ($row = mysqli_fetch_array($result2)) {
                ?>
                <div class="cardBox">
                    <div class="bookBox">
                        <a href="../includes/books.php?source=description&description=<?php echo $row['id'] ?>"><?php echo '<img src="data:image;base64,' . base64_encode($row['bookImage']) . '" alt="image">'; ?>
                            <div>View Detail</div>
                        </a>
                    </div><!-- bookBox section close -->
                    <p><?php echo $row['bookName'] ?><br>Rs.<?php echo $row['bookPrice'] ?></p>
                </div><!-- cardBox section close -->

                <?php } ?>

            </div><!-- bookSlider section closer -->

        </div><!-- content-2 section close -->

        <div class="content-3">
            <div class="line"></div>
            <div class="tagline">
                <p>THERE’S NO<br>
                    SUCH THINGS AS GOOD<br>
                    AS BOOKS<br></p>
                <button> <a href="OurStory.php" style="text-decoration:none; color:#fff;">Read Our Story</a></button>
            </div><!-- tagline section close -->
            <div class="line"></div>
        </div><!-- content-3 sectoin close -->

    </div><!-- content section close -->

    <div class="bookLaunch">
        <div class="heading">
            <div class="hd-top">
                <p>Comming Up</p>
            </div><!-- hd-top section close -->
            <div class="hd-bottom">
                <p>BOOK LAUNCH</p>
            </div><!-- hd-bottom section close -->
        </div><!-- heading section close -->

        <div class="launchCntImg">
            <div class="launchCnt">
                <p>Introducing The Land Of ALLOO<br><br>By Mark Walker<br><br>It is a long established fact that a
                    reader
                    will be distracted by the readable
                    content of a page when looking at its
                    layout. The point of using Lorem Ipsum<br><br>When<br>May 12, 2023</p><br><br><br>
                <button>RESERVE FOR ME</button>
            </div><!-- launchCnt section close -->
            <div class="launchImg">
                <img src="../images/book_launch-img.png" alt="launch-book">
            </div><!-- launchImg section close -->
        </div><!-- launchCntIng section close-->

    </div><!-- bookLaunch section close -->

</main><!-- main section close -->

<?php
    include "../includes/footer.php";
?>

</body>

</html>
