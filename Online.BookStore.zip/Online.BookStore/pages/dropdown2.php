<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="style2.css">
</head>
<body>

    <header>
        <div class="logo">
            <a href="#"><i class="bl">Online.</i><i class="wh">Book Store</i></a>
        </div><!-- logo section close -->
        <div class="nav">
            <ul>
                <li><a href="#">Book Store</a></li>
                <li><a href="#">About</a></li>
                <li><a href="#">Contact</a></li>
                <li><a href="#"><i class="fa fa-user-circle"></i>Log In</a>
                    <div class="dropdown-1">
                        <ul>
                            <li><a href="#">Sign Out</a></li>
                            <li><a href="#">Books</a>
                                <div class="dropdown-2">
                            <ul>
                                <li><a href="#">Add Book</a></li>
                                <li><a href="#">Recently Added</a></li>
                                <li><a href="#">Order Request</a></li>
                            </ul>
                            </div>
                            </li>
                            <li><a href="#">Transactions</a></li>
                        </ul>
                    </div>
                </li>
                <li><a href="#"><i class="fa fa-shopping-cart"></i></a></li>
            </ul>
        </div><!--- nav section close -->
         </header><!--- header section close -->
    
         <div class="banner">
            <img src="images/banner-img.png" alt="banenr-img">
        </div><!-- banner section close -->

        <div class="content">
            <div class="content-1">
                <div class="heading">
                    <div class="hd-top">
                        <p>Online. Book Store</p>
                    </div><!-- hd-top section close -->
                    <div class="hd-bottom">
                        <p>BESTSELLERS</p>
                    </div><!-- hd-bottom section close -->
                </div><!-- heading section close -->
                <div class="bookSlider">
                    <div class="cardBox">
                        <div class="bookBox">
                           <a href="#"><img src="images/bestsellers/bestsellers-img-1.png" alt="">
                           <div>View Detail</div>
                           </a>
                        </div><!-- bookBox section close -->
                        <p>I'm a Product<br>Rs. 25.00</p>
                    </div><!-- cardBox section close -->
   
                    <div class="cardBox">
                       <div class="bookBox">
                           <a href="#"><img src="images/bestsellers/bestsellers-img-2.png" alt="">
                               <div>View Detail</div>
                           </a>
                       </div><!-- bookBox section close -->
                       <p>I'm a Product<br>Rs. 25.00</p>
                   </div><!-- cardBox section close -->
   
                   <div class="cardBox">
                       <div class="bookBox">
                           <a href="#"><img src="images/bestsellers/bestsellers-img-3.png" alt="">
                               <div>View Detail</div>
                           </a>          
                       </div><!-- bookBox section close -->
                       <p>I'm a Product<br>Rs. 25.00</p>
                   </div><!-- cardBox section close -->
   
                   <div class="cardBox">
                       <div class="bookBox">
                           <a href="#"><img src="images/bestsellers/bestsellers-img-4.png" alt="">
                               <div>View Detail</div>
                           </a>
                       </div><!-- bookBox section close -->
                       <p>I'm a Product<br>Rs. 25.00</p>
                   </div><!-- cardBox section close -->
   
                   <div class="cardBox">
                       <div class="bookBox">
                           <a href="#"><img src="images/bestsellers/bestsellers-img-5.png" alt="">
                               <div>View Detail</div>
                           </a>
                       </div><!-- bookBox section close -->
                       <p>I'm a Product<br>Rs. 25.00</p>
                   </div><!-- cardBox section close -->
   
                </div><!-- bookSlider section closer -->
            </div><!-- content-1 section close -->
   
            <div class="content-2">
               <div class="line"></div>
               <div class="heading">
                   <div class="hd-top">
                       <p>Online. Book Store</p>
                   </div><!-- hd-top section close -->
                   <div class="hd-bottom">
                       <p>RECOMMENDED BOOKS</p>
                   </div><!-- hd-bottom section close -->
               </div><!-- heading section close -->
               <div class="line"></div>
               <div class="bookSlider">
                   <div class="cardBox">
                       <div class="bookBox">
                           <a href="#"> <img src="images/recommended/recommended-img-1.png" alt="">
                               <div>View Detail</div>
                           </a>
                       </div><!-- bookBox section close -->
                       <p>I'm a Product<br>Rs. 25.00</p>
                   </div><!-- cardBox section close -->
   
                   <div class="cardBox">
                       <div class="bookBox">
                          <a href="#"><img src="images/recommended/recommended-img-2.png" alt="">
                           <div>View Detail</div>
                       </a>
                       </div><!-- bookBox section close -->
                       <p>I'm a Product<br>Rs. 25.00</p>
                   </div><!-- cardBox section close -->
   
                   <div class="cardBox">
                       <div class="bookBox">
                           <a href="#"><img src="images/recommended/recommended-img-3.png" alt="">
                               <div>View Detail</div>
                           </a>
                       </div><!-- bookBox section close -->
                       <p>I'm a Product<br>Rs. 25.00</p>
                   </div><!-- cardBox section close -->
   
                   <div class="cardBox">
                       <div class="bookBox">
                           <a href="#"><img src="images/recommended/recommended-img-4.png" alt="">
                               <div>View Detail</div>
                           </a>
                       </div><!-- bookBox section close -->
                       <p>I'm a Product<br>Rs. 25.00</p>
                   </div><!-- cardBox section close -->
   
                   <div class="cardBox">
                       <div class="bookBox">
                           <a href="#"><img src="images/recommended/recommended-img-5.png" alt="">
                               <div>View Detail</div>
                           </a>
                       </div><!-- bookBox section close -->
                       <p>I'm a Product<br>Rs. 25.00</p>
                   </div><!-- cardBox section close -->
   
               </div><!-- bookSlider section closer -->
              
            </div><!-- content-2 section close -->
   
            <div class="content-3">
               <div class="line"></div>
               <div class="tagline">
                <p>THERE’S NO<br>
                   SUCH THINGS AS GOOD<br>
                   AS BOOKS<br></p>
                   <button>Read Our Story</button>
               </div><!-- tagline section close -->
                   <div class="line"></div>
            </div><!-- content-3 sectoin close -->
   
        </div><!-- content section close -->

</body>
</html>