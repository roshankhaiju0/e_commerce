<?php
    include "../includes/header.php";
    require_once "../config/db.php";

    if(isset($_POST['submit'])){
        $username = $_POST['username'];
        $email = $_POST['email'];
        $message = $_POST['message'];

        $query = "INSERT INTO `contact_us`(`contact_us_visitor_username`, `contact_us_visitor_email`, `contact_us_visitor_message`) VALUES ('$username','$email','$message')";
        $result = mysqli_query($connection, $query);
    }

?>

<main>

    <div class="ourContact-cnt">

        <div class="heading">
            <div class="hd-top">
                <p>For More Info</p>
            </div><!-- hd-top section close -->
            <div class="hd-bottom">
                <p>CONTACT US</p>
            </div><!-- hd-bottom section close -->
        </div><!-- heading section close -->

        <div class="ourContact-contact-bx">

            <div class="ourContact-contact">

                <div class="ourContact-contact-store">
                    <p class="p24">Store</p><br>
                    <ul>
                        <li>Address</li>
                        <li>Koteshwor, Tinkune</li>
                        <li>Kathmandu, Nepal 44600</li>
                        <br>
                        <li>Tel</li>
                        <li>123-456-7890</li>
                        <br>
                        <li>Email</li>
                        <li>online.bookstore@info.com</li>
                    </ul>
                </div><!-- ourContact-contact-store section close -->

                <div class="ourContact-contact-customer-service">
                    <p class="p24">Customer Serivce</p><br>
                    <ul>
                        <li>Tel</li>
                        <li>123-456-7890</li>
                        <br><br>
                        <li>Email</li>
                        <li>online.bookstore@info.com</li>
                    </ul>
                </div><!-- ourContact-contact-store-customer-service section close -->

                <!-- <div class="ourContact-contact-message-sec"> -->
                    <form action="" method="post" class="ourContact-contact-message-sec">
                        <div class="ourContact-contact-message-sec-name">
                            <input type="text" name="username" placeholder="Name">
                            <hr>
                        </div><!-- ourContact-contact-message-sec-name section close -->

                        <div class="ourContact-contact-message-sec-email">
                            <input type="text" name="email" placeholder="Email">
                            <hr>
                        </div><!-- ourContact-contact-message-sec-email section close -->

                        <div class="ourContact-contact-message-sec-message">
                            <!-- <input type="text" placeholder="Enter your message here ... "> -->
                            <textarea name="message" id="" cols="100" rows="15"
                                placeholder="Enter your message here ... "></textarea>
                            <hr>
                            <button type="submit" name="submit">Submit</button>
                    </form>
                <!-- </div> -->
                <!-- ourContact-contact-message-sec-message section close -->

            </div><!-- ourContact-contact-message-sec section close -->

        </div><!-- ourContact-contact section close -->

        <div class="ourContact-bx"></div><!-- ourContact-bx section close -->

    </div><!-- ourContact-contact-bx section close -->

    </div><!-- ourContact-cnt section close-->


</main>

<?php
    include "../includes/footer.php";
?>

</body>

</html>
