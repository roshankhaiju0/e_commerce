<?php
include "../includes/header.php";
?>

        <main>

            <div class="ourStory-cnt">

                <div class="heading">
                    <div class="hd-top">
                        <p>Our</p>
                    </div><!-- hd-top section close -->
                    <div class="hd-bottom">
                        <p>STORY</p>
                    </div><!-- hd-bottom section close -->
                </div><!-- heading section close -->

                <div class="ourStory-img-bx">

                    <div class="ourStory-bx2"></div><!-- ourStory-bx2 section close -->

                    <div class="ourStory-img">
                        <img src="../images/stack-books.png" alt="">
                    </div><!-- ourStory-img section close -->

                    <div class="ourStory-bx">
                        <p>Contrary to popular belief, Lorem Ipsum is not
                            simply random text. It has roots in a piece of
                            classical Latin literature from 45 BC, making it over
                            2000 years old. Richard McClintock, a Latin
                            professor at Hampden-Sydney College in Virginia,
                            looked up one of the more obscure Latin words,
                            <br><br>
                            through the cites of the word in classical literature,
                            discovered the undoubtable source. Lorem Ipsum
                            comes from sections 1.10.32 and 1.10.33 of "de Finibus
                            Bonorum et Malorum" (The Extremes of Good and
                            Evil) by Cicero, written in 45 BC. This book is a treatise
                            on the theory of ethics, very popular during the
                            Renaissance. The first line of Lorem Ipsum, "Lorem
                            ipsum dolor sit amet..", comes from a line in
                            section 1.10.32.</p>
                    </div><!-- ourStory-bx2 section close -->

                </div><!-- ourStory-cnt-img-bx section close -->

            </div><!-- ourStory-cnt section close-->


        </main>

       <?php
       include "../includes/footer.php";
       ?>


    </body>

</html>
