<?php
    include "../includes/header.php";
    require_once "../config/db.php";
    
    

    $query  = "SELECT * FROM books ORDER BY id DESC";
    $result = mysqli_query($connection, $query);

    include "../category/CategoryFilter.php";
    
?>

<main>
    <div class="bookstore-cnt">

        <div class="heading">
            <div class="hd-top">
                <p>Online. Book Store</p>
            </div><!-- hd-top section close -->
            <div class="hd-bottom">
                <p>BOOKSTORE</p>
            </div><!-- hd-bottom section close -->
        </div><!-- heading section close -->

        <div class="bookstore-bk">
          
          <div class="search-filter">
          <div class="heading">
              Search By
          </div><!-- filter by heading seciton close -->
          <br>
          <hr>
          <br>
          <form action="" method="post" class="bookSearch">
              <input type="text" class="searchBook" name="searchBook" placeholder="book name, author name...">
              <button type="submit" name="search" class="search"> Search</button>
          </form>
          <br>
          <hr>
          <br>
          <ul>
              <li style="margin-bottom: 10px;"><a>Categories</li>
              <li><a href="../includes/books.php?source=&bookCat=all">All</a></li>
              <li><a href="../includes/books.php?source=fiction&bookCat=Fiction">Fiction</a></li>
              <li><a href="../includes/books.php?source=design&bookCat=Design and Art">Design & Art</a></li>
              <li><a href="../includes/books.php?source=romance&bookCat=Romance">Romance</a></li>
              <li><a href="../includes/books.php?source=travel&bookCat=Travel Guide">Travel Guide</a></li>
              <li><a href="../includes/books.php?source=thriller&bookCat=Thriller">Thriller</a></li>
              <li><a href="../includes/books.php?source=adventure&bookCat=Adventure">Adventure</a></li>
          </ul> 
          <br>
          <hr>
          <br>
          <li><a href="#">Price</a></li>
          <br>
          <form action="" method="POST">
              <p> Min: <input type="number" name="min"> Max: <input type="number" name="max"></p><br>
              <button type="submit" name="submit" class="search">Search</button>
          </form>
      </div><!-- search filter section close -->

            <div class="cnt-books">

                <?php
                    while ($row = mysqli_fetch_array($result)) {
                    ?>

                <div class="cnt-books-card">
                    <div class="cnt-books-img-bx">
                        <a href="bookDescription.php"><?php echo '<img src="data:image;base64,' . base64_encode($row['bookImage']) . '" alt="image">'; ?>
                            <div><a href="../includes/books.php?source=description&description=<?php echo $row['id'] ?>">View Detail</a>
                            </div>
                        </a>
                    </div><!-- cnt-books-img-bx section close -->
                    <p><?php echo $row['bookName'] ?><br>Rs.<?php echo $row['bookPrice'] ?></p>
                </div><!-- cnt-books-card section close -->



                <?php
                    }
                ?>

            </div><!-- cnt-books section close -->

        </div><!-- bookstore-bk section close -->

    </div><!-- bookstore-cnt section close -->

</main><!-- main section close -->

<?php include "../includes/footer.php" ?>


</body>

</html>
