<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="style2.css">
</head>
<body>

    <header>
        <div class="logo">
            <a href="#"><i class="bl">Online.</i><i class="wh">Book Store</i></a>
        </div><!-- logo section close -->
        <div class="nav">
            <ul>
                <li><a href="#">Book Store</a></li>
                <li><a href="#">About</a></li>
                <li><a href="#">Contact</a></li>
                <li><a href="#"><i class="fa fa-user-circle"></i> Log In</a>
                    <div class="dropdown-1">
                        <ul>
                            <li><a href="#">Sign Out</a></li>
                            <li><a href="#">Transactions</a></li>
                        </ul>
                    </div>
                </li>
                <li><a href="#"><i class="fa fa-shopping-cart"></i></a></li>
            </ul>
        </div><!--- nav section close -->
         </header><!--- header section close -->
    
</body>
</html>