<?php
include "../includes/header.php";
?>

        <main>

            <div class="storePolicy-cnt">

                <div class="heading">
                    <div class="hd-top">
                        <p>Online. Book Store</p>
                    </div><!-- hd-top section close -->
                    <div class="hd-bottom">
                        <p>STORE POLICY</p>
                    </div><!-- hd-bottom section close -->
                </div><!-- heading section close -->

                <div class="storePolicy-info-bx">

                    <div class="storePolicy-info">

                        <p class="p30">Customer Care</p><br>
                        <p>I’m a customer care section. I’m a great place to write a long text about your company and
                            your services, and, most importantly, how to contact your store with queries. Writing a
                            detailed customer care policy is a great way to build trust and reassure your customers that
                            they can buy with confidence. </p><br>
                        <p>I'm the second paragraph in your customer care section. Click here to add your own text
                            and edit me. It’s easy. Just click “Edit Text” or double click me to add details about your
                            policy and make changes to the font. I’m a great place for you to tell a story and let your
                            users know a little more about you. </p>
                        <br><br>
                        <p class="p30">Privacy & Safety</p><br>
                        <p>I’m a privacy & safety policy section. I’m a great place to inform your customers about
                            how you use, store, and protect their personal information. Add details such as how you
                            use third-party banking to verify payment, the way you collect data or when will you
                            contact users after their purchase was completed successfully. </p><br>
                        <p>Your user’s privacy is of the highest importance to your business, so take the time to write
                            an accurate and detailed policy. Use straightforward language to gain their trust and make
                            sure they keep coming back to your site!</p>
                        <br><br>
                        <p class="p30">Wholesale Inquiries</p><br>
                        <p>I’m a wholesale inquiries section. I’m a great place to inform other retailers about how t
                            hey can sell your stunning products. Use plain language and give as much information as
                            possible in order to promote your business and take it to the next level!</p><br>
                        <p>
                            I'm the second paragraph in your wholesale inquiries section. Click here to add your own
                            text and edit me. It’s easy. Just click “Edit Text” or double click me to add details about
                            your
                            policy and make changes to the font. I’m a great place for you to tell a story and let your
                            users
                            know a little more about you.</p>
                        <br><br>
                        <p class="p30">Payment Methods</p><br>
                        <p>
                            <li>cash on Delivery</li>
                        </p>

                    </div><!-- shippingReturns-info section close -->

                    <div class="storePolicy-bx"></div><!-- shippingReturns-bx section close -->

                </div><!-- shippingReturns-info-bx section close -->

            </div><!-- shippingReturns-cnt section close-->


        </main>

       <?php
       include "../includes/footer.php";
       ?>

    </body>

</html>
