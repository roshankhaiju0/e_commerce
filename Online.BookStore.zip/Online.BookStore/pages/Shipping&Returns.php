<?php
include "../includes/header.php";
?>

        <main>

            <div class="shippingReturns-cnt">

                <div class="heading">
                    <div class="hd-top">
                        <p>Online. Book Store</p>
                    </div><!-- hd-top section close -->
                    <div class="hd-bottom">
                        <p>SHIPPING & RETURNS</p>
                    </div><!-- hd-bottom section close -->
                </div><!-- heading section close -->

                <div class="shippingReturns-info-bx">

                    <div class="shippingReturns-info">
                        <p class="p30">Shipping Policy</p><br>
                        <p>I’m a shipping policy section. I’m a great place to update your customers about your shipping
                            methods, packaging and costs. Use plain, straightforward language to build trust and make
                            sure that your customers stay loyal!</p><br>
                        <p>I'm the second paragraph in your shipping policy section. Click here to add your own text and
                            edit me. It’s easy. Just click “Edit Text” or double click me to add details about your
                            policy and make changes to the font. I’m a great place for you to tell a story and let your
                            users know a little more about you</p>
                        <br><br>
                        <p class="p30">Returns & Exchange Policy</p><br>
                        <p>I’m a return policy section. I’m a great place to let your customers know what to do in case
                            they’ve changed their mind about their purchase, or if they’re dissatisfied with a product.
                            Having a straightforward refund or exchange policy is a great way to build trust and
                            reassure your customers that they can buy with confidence.</p><br>
                        <p>I'm the second paragraph in your return & exchange policy. Click here to add your own text
                            and edit me. It’s easy. Just click “Edit Text” or double click me to add details about your
                            policy and make changes to the font. I’m a great place for you to tell a story and let your
                            users know a little more about you.</p>
                    </div><!-- shippingReturns-info section close -->

                    <div class="shippingReturns-bx"></div><!-- shippingReturns-bx section close -->

                </div><!-- shippingReturns-info-bx section close -->

            </div><!-- shippingReturns-cnt section close-->


        </main>

       <?php
       include "../includes/footer.php";
       ?>

    </body>

</html>
