<?php
    require_once "./config/db.php";

    $query  = "SELECT * FROM customerusers";
    $result = mysqli_query($connection, $query);

    while ($row = mysqli_fetch_assoc($result)) {
    ?>
    <pre>
    <?php
        print_r($row);
        ?>
    </pre>
    <?php
        }

    ?>

<?php

    $query  = "SELECT * FROM vendorusers";
    $result = mysqli_query($connection, $query);

    while ($row = mysqli_fetch_assoc($result)) {
    ?>
    <pre>
    <?php
        print_r($row);
        ?>
    </pre>
    <?php
        }

    ?>

    <?php
session_start();
echo $_SESSION["username"];
echo '<br><br><br>';
    ?>

    <?php

$query3  = "SELECT COUNT(*) AS NUMBER FROM cart";
$result3 = mysqli_query($connection, $query3);
while($row = mysqli_fetch_array($result3)){
    $count = $row['NUMBER'];
}

$current_date = date("Y-m-d");
echo $current_date;
echo "<br><br>";
$date=date_create($current_date);
date_modify($date,"-1 year");
$changed_date = date_format($date,"Y-m-d");
echo $changed_date;

$date_data = "SELECT * FROM test WHERE ordedate = '$current_date'";
$res = mysqli_query($connection, $date_data);
while($row = mysqli_fetch_array($res)){
    echo $row['id'];
}

if(isset($_POST['submit'])){
    $firstDate = $_POST['dateFirst'];
    $secondDate = $_POST['dateSecond'];

    echo $firstDate;
    echo "<br><br>";
    echo $secondDate;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="post">
      1st Date: <input type="date" name="dateFirst" id="">
      <br><br>
      2nd Date: <input type="date" name="dateSecond" id="">
      <input type="submit" name="submit" value="SUBMIT">
    </form>
</body>
</html>