<?php
session_start();
include "../config/db.php";
$current_date = date("Y-m-d");
echo "<style>
.badge{
background-color: rgba(0, 0, 0, 0.1);
border-radius: 40%;
padding: 5px 10px;
}
</style>";



if (isset($_SESSION['username'])) {
    if ($_SESSION['userType'] == 'vendor') {
        include "../includes/vendorHeader.php";
    }
    if ($_SESSION['userType'] == 'customer') {
        include "../includes/customerHeader.php";
    }
} else {
    include "../includes/anonymousHeader.php";
}
