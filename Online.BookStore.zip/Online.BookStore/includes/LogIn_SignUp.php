<?php
if (isset($_GET['source'])) {
    $source = $_GET['source'];
} else {
    $source = "";
}

switch ($source) {

    case 'customer_login';
        include "../customer/loginCustomer.php";
        break;

    case 'vendor_login';
        include "../vendor/VendorSignIn.php";
        break;

    case 'vendor_signup';
        include "../vendor/signUpVendor.php";
        break;

    case 'customer_signup';
        include "../customer/signupCustomer.php";
        break;

    default:
        include "../pages/index.php";
        break;

}
