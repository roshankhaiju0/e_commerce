<?php

if (isset($_GET)) {
    $source = $_GET['source'];
} else {
    $source = "";
}

switch ($source) {

    case 'fiction';
        include "../category/Fiction.php";
        break;

    case 'design';
        include "../category/DesignAndArt.php";
        break;

    case 'travel';
        include "../category/TravelGuide.php";
        break;

    case 'romance';
        include "../category/Romance.php";
        break;

    case 'thriller';
        include "../category/Thriller.php";
        break;

    case 'adventure';
        include "../category/Adventure.php";
        break;

    case 'description';
        include "../pages/bookDescription.php";
        break;

    default:
        include "../pages/bookstore.php";
        break;

}
