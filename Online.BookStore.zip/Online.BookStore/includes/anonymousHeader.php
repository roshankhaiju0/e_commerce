<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Store</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/style2.css">
</head>
<body>
    
    <header>
        <div class="logo">
            <a href="../pages/index.php"><i class="bl">Online.</i><i class="wh">Book Store</i></a>
        </div><!-- logo section close -->
        <div class="nav">
            <ul>
                <li><a href="../includes/books.php?source=&bookCat=all">Book Store</a></li>
                <li><a href="../pages/OurStory.php">About</a></li>
                <li><a href="../pages/OurContact.php">Contact</a></li>
                <li><a><i class="fa fa-user-circle"></i>Log In</a>
                    <div class="dropdown-1">
                        <ul>
                            <li><a href="../includes/LogIn_SignUp.php?source=vendor_login">Vendor</a></li>
                            <li><a href="../includes/LogIn_SignUp.php?source=customer_login">Customer</a></li>
                        </ul>
                    </div>
                </li>
                <li onclick="loginToViewCart()"><a href=""><i class="fa fa-shopping-cart"></i></a></li>
            </ul>
        </div><!--- nav section close -->
         </header><!--- header section close -->

         <script>
function loginToViewCart(){
    alert("login as customer to view cart");
}
             </script>