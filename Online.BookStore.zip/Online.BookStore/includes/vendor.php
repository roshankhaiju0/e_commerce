<?php

if(isset($_GET['source'])){
    $source = $_GET['source'];
}else{
    $source = "";
}

switch($source){

case 'sign_out';
include "../pages/index.php";
break;

case 'manage_account';
include "../vendor/vendorUpdateProfile.php";

case 'add_book';
include "../vendor/vendorAddBook.php";
break;

case 'edit_book';
include "../vendor/editBook.php";
break;

case 'order_request';
include "../vendor/orderRequest.php";
break;

case 'transactions';
include "../vendor/vendorDailyTransaction.php";
break;

case 'daily';
$current_date = date("Y-m-d");
$date=date_create($current_date);
date_modify($date,"-7 days");
$changed_date = date_format($date,"Y-m-d");
include "../vendor/vendorDailyTransaction.php";
break;

case 'weekly';
$current_date = date("Y-m-d");
$date=date_create($current_date);
date_modify($date,"-7 days");
$changed_date = date_format($date,"Y-m-d");
include "../vendor/vendorWeeklyTransaction.php";
break;

case 'monthly';
$current_date = date("Y-m-d");
$date=date_create($current_date);
date_modify($date,"-1 month");
$changed_date = date_format($date,"Y-m-d");
include "../vendor/vendorMonthlyTransaction.php";
break;

case 'custom';
$current_date = date("Y-m-d");
include "../vendor/vendorCustomTransaction.php";
break;

default:
echo "<script>window.open('../vendor/vendorViewBooks.php','_self');</script>" ;
include "../vendor/vendorViewBooks.php";
break;

}

?>