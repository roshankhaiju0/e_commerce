<?php

if(isset($_GET['source'])){
    $source = $_GET['source'];
}else{
    $source = "";
}

switch($source){

case 'transactions';
include "../customer/customerWeeklyTransaction.php";
break;

case 'history';
include "../customer/customerTransactionHistory.php";
break;

case 'weekly';
$current_date = date("Y-m-d");
$date=date_create($current_date);
date_modify($date,"-7 days");
$changed_date = date_format($date,"Y-m-d");
include "../customer/customerWeeklyTransaction.php";
break;

case 'monthly';
$current_date = date("Y-m-d");
$date=date_create($current_date);
date_modify($date,"-1 month");
$changed_date = date_format($date,"Y-m-d");
include "../customer/customerMonthlyTransaction.php";
break;

case 'custom';
$current_date = date("Y-m-d");
include "../customer/customerCustomTransaction.php";
break;

case 'view_cart';
echo "<script>window.open('../customer/myCart-orderSummary.php','_self');</script>" ;
include "../customer/myCart-orderSummary.php";
break;

default:
include "../pages/index.php";
break;

}

?>