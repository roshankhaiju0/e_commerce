<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Customer Custom Transaction</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css">
        <link rel="stylesheet" href="../css/style.css">
        <link rel="stylesheet" href="../css/style2.css">
    </head>

    <body>

        <header>

            <div class="cart-modal">
                <div class="cart-modal-content">
                    <div class="cart">

                        <div class="cart-top">
                            <p><i class="right-carret" id="right">&#62;</i>Cart</p>
                        </div><!-- cart-top section close -->

                        <div class="cart-mid">
                            <div class="cart-mid-des">
                                <div class="cart-mid-des-bookBx">
                                    <img src="../images/recommended/recommended-img-3.png" alt="">
                                </div><!-- cart-mid-des-bookBx section close -->
                                <div class="cart-mid-des-bookDes">
                                    <p>I'm a Product <br>
                                        <strong>QTY: 3</strong><br>
                                        <strong>Rs. 25.00</strong>
                                    </p>
                                </div><!-- cart-mid-des-bookDes section close -->
                                <div class="cart-mid-des-cross">
                                    <i>&times;</i>
                                </div><!-- cart-mid-des-cross section close -->
                            </div><!-- cart-mid-des section -->

                            <div class="cart-mid-des">
                                <div class="cart-mid-des-bookBx">
                                    <img src="../images/recommended/recommended-img-4.png" alt="">
                                </div><!-- cart-mid-des-bookBx section close -->
                                <div class="cart-mid-des-bookDes">
                                    <p>I'm a Product <br>
                                        <strong>QTY: 3</strong><br>
                                        <strong>Rs. 25.00</strong>
                                    </p>
                                </div><!-- cart-mid-des-bookDes section close -->
                                <div class="cart-mid-des-cross">
                                    <i>&times;</i>
                                </div><!-- cart-mid-des-cross section close -->
                            </div><!-- cart-mid-des section -->

                            <div class="cart-mid-des">
                                <div class="cart-mid-des-bookBx">
                                    <img src="../images/recommended/recommended-img-6.png" alt="">
                                </div><!-- cart-mid-des-bookBx section close -->
                                <div class="cart-mid-des-bookDes">
                                    <p>I'm a Product <br>
                                        <strong>QTY: 2</strong><br>
                                        <strong>Rs. 25.00</strong>
                                    </p>
                                </div><!-- cart-mid-des-bookDes section close -->
                                <div class="cart-mid-des-cross">
                                    <i>&times;</i>
                                </div><!-- cart-mid-des-cross section close -->
                            </div><!-- cart-mid-des section -->
                        </div><!-- cart-mid section close -->

                        <div class="cart-bottom">
                            <p>Subtotal <br> Rs. 200.00</p>
                            <hr>
                            <button><a href="myCart-orderSummary.php"> View Cart</a></button>
                        </div><!-- cart-bottom section close -->

                    </div><!-- cart section close -->
                </div><!-- cart-modal-content section close -->
            </div><!-- cart-modal section close -->
            <div class="logo">
                <a href="../pages/index.php"><i class="bl">Online.</i><i class="wh">Book Store</i></a>
            </div><!-- logo section close -->
            <div class="nav">
                <ul>
                    <li><a href="../pages/OurStory.php">About</a></li>
                    <li><a href="../pages/OurContact.php">Contact</a></li>
                    <li><a href="#"><i class="fa fa-user-circle"></i> <?php echo $_SESSION['username'] ?></a>
                        <div class="dropdown-1">
                            <ul>
                                <li><a href="../includes/sessionDestroy.php">Sign Out</a></li>
                                <li><a href="../includes/vendor.php?source=manage_account">Manage Account</a></li>
                                <li><a>Books</a>
                                    <div class="dropdown-2">
                                        <ul>
                                            <li><a href="../includes/vendor.php?source=add_book">Add Book</a></li>
                                            <li><a href="../includes/vendor.php">Recently Added</a></li>
                                            <li><a href="../includes/vendor.php?source=order_request">Order Request</a>
                                            </li>
                                        </ul>
                                    </div>
                                </li>
                                <li><a href="../includes/vendor.php?source=daily">Transactions</a></li>
                            </ul>
                        </div>
                    </li>
                </ul>
            </div><!--- nav section close -->
        </header>
        <!--- header section close -->
