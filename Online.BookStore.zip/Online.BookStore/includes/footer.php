<?php 

if(isset($_POST['submit'])){
    $subscribers = $_POST['subscribe'];
    $query = "INSERT INTO `subscribers`( `subscribers_email`) VALUES ('$subscribers')";
    $result = mysqli_query($connection, $query);
    if(!$result){
        die('QUERY FAILED ' . mysqli_error($connection));
    }
}

?>


<footer>
    <div class="ftr-top">
        <div class="ftr-1">
            <li>Online. Book Store</li><br><br>
            <li>Koteshwor, Tinkune</li><br>
            <li>Kathmandu, Nepal 44600</li><br>
            <li>123 - 456 - 7890</li><br>
            <li>online.bookstore@info.com</li><br>
        </div><!-- ftr-1 section close -->
        <div class="ftr-2">
            <li>Store</li><br><br>
            <li><a href="../pages/Shipping&Returns.php">Shipping & Returns</a></li><br>
            <li><a href="../pages/StorePolicy.php">Store Policy</a></li><br>
            <li><a href="../pages/StorePolicy.php">Payment Method</a></li><br>
           
        </div><!-- ftr-2 section close -->
        <div class="ftr-3">
            <li>Socials</li><br><br>
            <li><a href="www.facebook.com/OnlineBookStore">Facebook</a></li><br>
            <li><a href="www.twitter.com/OnlineBookStore">Twitter</a></li><br>
            <li><a href="www.instagram.com/OnlineBookStore">Instagram</a></li><br>
            <li><a href="www.pinterest.com/OnlineBookStore">Pinterest</a></li><br>
        </div><!-- ftr-3 section close -->
        <div class="ftr-4">
            <li>Be The First TO Know</li><br><br>
            <li>Sign up for our newsletter</li><br>
            <form action="" method="POST">
            <input class="em" type="text" name="subscribe" placeholder="enter your email here*"><br><br>
            <button type="submit" name="submit">Subscribe</button>
            </form>
        </div><!-- ftr-4 section close -->
    </div><!-- ftr-top section close-->
    <div class="ftr-bottom">
        <p>2020 by Online. Book Store. Fictitious Business. &copy; <?php echo date("Y");?></p>
    </div><!-- ftr-bottom close -->
</footer><!-- footer section close -->